package com.noostore.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Product(val id:Int, val nameBn:String, val nameEn:String, val price:Int)

private val products = listOf(
    Product(1,"আম","Mango",120),
    Product(2,"কলা","Banana",60),
    Product(3,"টমেটো","Tomato",50),
    Product(4,"পেঁয়াজ","Onion",80),
    Product(5,"চাল","Rice",75),
    Product(6,"সয়াবিন তেল","Soybean Oil",170)
)

@Composable
fun App() {
    var lang by remember { mutableStateOf("bn") }
    var screen by remember { mutableStateOf("home") }
    var cart by remember { mutableStateOf(listOf<Product>()) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var orderPlaced by remember { mutableStateOf(false) }

    val bn = lang == "bn"
    val title = if (bn) "N.O.O STORE" else "N.O.O STORE"

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF087A43))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(title, fontWeight = FontWeight.Bold) },
                    actions = {
                        TextButton(onClick = { lang = if (bn) "en" else "bn" }) {
                            Text(if (bn) "English" else "বাংলা")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = screen=="home", onClick={screen="home"},
                        icon={Text("🏠")}, label={ { Text(if(bn)"হোম" else "Home") } })
                    NavigationBarItem(selected = screen=="cart", onClick={screen="cart"},
                        icon={Text("🛒")}, label={ { Text(if(bn)"কার্ট" else "Cart") } })
                    NavigationBarItem(selected = screen=="orders", onClick={screen="orders"},
                        icon={Text("📦")}, label={ { Text(if(bn)"অর্ডার" else "Orders") } })
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    orderPlaced -> {
                        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally,
                            verticalArrangement=Arrangement.Center) {
                            Text("✓", fontSize=64.sp, color=MaterialTheme.colorScheme.primary)
                            Text(if(bn) "অর্ডার সফল হয়েছে!" else "Order placed successfully!",
                                fontSize=24.sp, fontWeight=FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Text(if(bn) "আপনার অর্ডার N.O.O STORE-এ পাঠানো হয়েছে।"
                                  else "Your order has been sent to N.O.O STORE.")
                            Spacer(Modifier.height(20.dp))
                            Button(onClick={ orderPlaced=false; screen="home"; cart=emptyList() }) {
                                Text(if(bn) "হোমে ফিরুন" else "Back to Home")
                            }
                        }
                    }
                    screen=="home" -> {
                        LazyColumn(Modifier.fillMaxSize().padding(16.dp),
                            verticalArrangement=Arrangement.spacedBy(12.dp)) {
                            item {
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(18.dp)) {
                                        Text(if(bn) "প্রয়োজনের সবকিছু, এখন এক ক্লিকেই!" else "Everything you need, one click away!",
                                            fontSize=20.sp, fontWeight=FontWeight.Bold)
                                        Spacer(Modifier.height(6.dp))
                                        Text(if(bn) "ডেলিভারি: চুয়াডাঙ্গা জেলা • তিতুদহ ইউনিয়ন ONLY"
                                              else "Delivery: Chuadanga District • Titudaho Union ONLY")
                                    }
                                }
                            }
                            item { Text(if(bn) "পণ্যসমূহ" else "Products", fontSize=21.sp, fontWeight=FontWeight.Bold) }
                            items(products) { p ->
                                Card(Modifier.fillMaxWidth()) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(if(bn)p.nameBn else p.nameEn, fontSize=18.sp, fontWeight=FontWeight.SemiBold)
                                            Text("৳ ${p.price}")
                                        }
                                        Button(onClick={ cart = cart + p }) {
                                            Text(if(bn) "কার্টে যোগ" else "Add")
                                        }
                                    }
                                }
                            }
                        }
                    }
                    screen=="cart" -> {
                        val total = cart.sumOf { it.price }
                        LazyColumn(Modifier.fillMaxSize().padding(16.dp),
                            verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            item { Text(if(bn)"আপনার কার্ট" else "Your Cart", fontSize=24.sp, fontWeight=FontWeight.Bold) }
                            if (cart.isEmpty()) item { Text(if(bn)"কার্ট খালি।" else "Cart is empty.") }
                            items(cart) { p ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                                    Text(if(bn)p.nameBn else p.nameEn, Modifier.weight(1f))
                                    Text("৳ ${p.price}")
                                }
                            }
                            if (cart.isNotEmpty()) {
                                item { Text("Total: ৳ $total", fontSize=20.sp, fontWeight=FontWeight.Bold) }
                                item {
                                    Button(onClick={screen="checkout"}, Modifier.fillMaxWidth()) {
                                        Text(if(bn)"অর্ডার করতে এগিয়ে যান" else "Proceed to Order")
                                    }
                                }
                            }
                        }
                    }
                    screen=="checkout" -> {
                        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                            Text(if(bn)"ডেলিভারি তথ্য" else "Delivery Information", fontSize=24.sp, fontWeight=FontWeight.Bold)
                            Text(if(bn)"শুধুমাত্র তিতুদহ ইউনিয়নে ডেলিভারি।"
                                  else "Delivery is available only in Titudaho Union.")
                            OutlinedTextField(name,{name=it},label={Text(if(bn)"নাম" else "Name")},Modifier.fillMaxWidth())
                            OutlinedTextField(phone,{phone=it},label={Text(if(bn)"মোবাইল নম্বর" else "Mobile number")},Modifier.fillMaxWidth())
                            OutlinedTextField(address,{address=it},label={Text(if(bn)"বাড়ি/গ্রাম/ঠিকানা" else "House/Village/Address")},Modifier.fillMaxWidth(),minLines=3)
                            Button(
                                onClick={ if(name.isNotBlank() && phone.isNotBlank() && address.isNotBlank()) orderPlaced=true },
                                Modifier.fillMaxWidth()) {
                                Text(if(bn)"অর্ডার নিশ্চিত করুন" else "Confirm Order")
                            }
                        }
                    }
                    screen=="orders" -> {
                        Column(Modifier.fillMaxSize().padding(16.dp)) {
                            Text(if(bn)"আমার অর্ডার" else "My Orders", fontSize=24.sp, fontWeight=FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Text(if(bn)"এখানে আপনার অর্ডারের অবস্থা দেখা যাবে।"
                                  else "Your order status will appear here.")
                        }
                    }
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
