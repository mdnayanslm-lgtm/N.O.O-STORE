# N.O.O STORE — Android App Starter

এটি N.O.O STORE-এর প্রথম Android MVP/source project।

## বর্তমান Version 1.0
- বাংলা / English language switch
- Product list + price
- Cart
- Customer name, phone, address
- Titudaho Union-only delivery notice
- Order confirmation screen
- My Orders screen placeholder

## গুরুত্বপূর্ণ
এই starter-এ এখনো online database/backend যুক্ত করা হয়নি। তাই বাস্তব customer order আপনার ফোনে পৌঁছানোর জন্য পরের ধাপে Firebase/Supabase backend এবং একটি Admin Panel যুক্ত করতে হবে।

## Android Studio দিয়ে চালানো
1. Android Studio খুলুন।
2. এই project folder open করুন।
3. Gradle sync শেষ করুন।
4. ফোন/Emulator নির্বাচন করুন।
5. Run চাপুন।

## পরের ধাপ
- Firebase/Supabase database
- Admin login
- Admin product add/edit/delete
- Real-time orders
- Titudaho Union geofence/location validation
- Customer order history
- Push notification
- Logo/images
- Payment method (প্রয়োজনে Cash on Delivery)
- Play Store release/AAB
